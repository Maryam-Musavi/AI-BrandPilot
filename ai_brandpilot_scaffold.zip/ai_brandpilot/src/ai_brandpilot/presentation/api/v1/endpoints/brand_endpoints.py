"""
FastAPI routes for the Brand resource.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
