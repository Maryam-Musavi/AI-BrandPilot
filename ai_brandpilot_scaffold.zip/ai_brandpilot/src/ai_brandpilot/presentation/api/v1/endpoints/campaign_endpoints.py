"""
FastAPI routes for the Campaign resource.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
