"""
FastAPI routes for health/readiness checks.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
