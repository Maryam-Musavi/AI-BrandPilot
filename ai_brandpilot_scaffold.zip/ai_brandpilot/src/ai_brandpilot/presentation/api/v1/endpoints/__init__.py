"""FastAPI route handlers grouped by resource."""
