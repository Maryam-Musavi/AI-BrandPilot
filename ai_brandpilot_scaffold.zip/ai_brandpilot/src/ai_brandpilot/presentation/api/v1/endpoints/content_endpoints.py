"""
FastAPI routes for the Content resource.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
