"""
Aggregates all v1 API routers.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
