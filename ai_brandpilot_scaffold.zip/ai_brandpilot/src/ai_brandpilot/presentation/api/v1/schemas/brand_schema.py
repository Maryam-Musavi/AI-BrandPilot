"""
Pydantic request/response schemas for Brand.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
