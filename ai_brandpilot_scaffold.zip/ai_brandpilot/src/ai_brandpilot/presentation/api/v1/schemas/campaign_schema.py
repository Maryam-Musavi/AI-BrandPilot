"""
Pydantic request/response schemas for Campaign.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
