"""
Pydantic request/response schemas for Content.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
