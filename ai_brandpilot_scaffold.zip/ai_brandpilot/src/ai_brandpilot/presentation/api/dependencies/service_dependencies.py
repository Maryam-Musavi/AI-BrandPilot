"""
FastAPI DI providers for application services.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
