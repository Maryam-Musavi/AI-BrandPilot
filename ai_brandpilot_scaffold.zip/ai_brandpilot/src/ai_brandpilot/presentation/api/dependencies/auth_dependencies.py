"""
FastAPI DI providers for authentication/authorization.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
