"""FastAPI dependency-injection providers."""
