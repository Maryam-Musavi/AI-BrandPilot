"""
Request/response logging middleware.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
