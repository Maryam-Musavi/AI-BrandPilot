"""
Global exception-handling middleware.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
