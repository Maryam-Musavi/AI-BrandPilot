"""Interface adapters: FastAPI routers, schemas, middleware, dependencies."""
