"""
Use case: retrieve brand details.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
