"""
Use case: create a new brand.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
