"""
Use case: update an existing brand.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
