"""
Use case: trigger content generation for a campaign.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
