"""Campaign-related use cases."""
