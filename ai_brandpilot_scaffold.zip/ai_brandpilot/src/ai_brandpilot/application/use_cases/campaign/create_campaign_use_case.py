"""
Use case: create a new campaign.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
