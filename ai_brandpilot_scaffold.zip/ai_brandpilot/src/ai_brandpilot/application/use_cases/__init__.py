"""Use case interactors, one responsibility per class (SRP)."""
