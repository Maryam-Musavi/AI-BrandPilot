"""
Port for supplying tools to agent workflows.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
