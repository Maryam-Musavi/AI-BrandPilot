"""Ports the application layer depends on (agent orchestration, tools, notifications)."""
