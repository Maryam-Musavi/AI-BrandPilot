"""
Port for outbound notification providers.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
