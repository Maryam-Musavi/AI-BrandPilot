"""Data transfer objects exchanged between use cases and callers."""
