"""
Data transfer objects for Content use cases.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
