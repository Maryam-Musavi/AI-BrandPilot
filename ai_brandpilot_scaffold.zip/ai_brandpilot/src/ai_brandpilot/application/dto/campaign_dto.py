"""
Data transfer objects for Campaign use cases.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
