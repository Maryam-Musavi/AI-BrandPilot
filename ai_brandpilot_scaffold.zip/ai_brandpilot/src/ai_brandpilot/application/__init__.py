"""Application business rules: use cases, DTOs, service layer, orchestration interfaces."""
