"""Abstract repository interfaces (ports) implemented by infrastructure."""
