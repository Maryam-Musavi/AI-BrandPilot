"""
Abstract repository port for the Brand aggregate.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
