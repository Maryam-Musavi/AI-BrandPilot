"""
Abstract repository port for the Campaign aggregate.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
