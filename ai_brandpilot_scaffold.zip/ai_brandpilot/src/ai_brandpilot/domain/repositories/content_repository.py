"""
Abstract repository port for the Content aggregate.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
