"""
Abstract repository port for the User aggregate.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
