"""
Domain service interface for content business rules.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
