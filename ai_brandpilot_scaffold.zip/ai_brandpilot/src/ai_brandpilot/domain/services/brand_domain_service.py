"""
Domain service interface for brand business rules.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
