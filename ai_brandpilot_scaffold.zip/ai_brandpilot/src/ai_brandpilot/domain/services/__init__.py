"""Domain service interfaces encapsulating core business rules."""
