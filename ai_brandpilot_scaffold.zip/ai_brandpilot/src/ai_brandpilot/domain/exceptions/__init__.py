"""Domain-layer exception types."""
