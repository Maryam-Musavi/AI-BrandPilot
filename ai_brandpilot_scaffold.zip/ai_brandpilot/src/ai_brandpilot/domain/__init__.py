"""Enterprise business rules: entities, value objects, repository interfaces, domain services. No framework dependencies."""
