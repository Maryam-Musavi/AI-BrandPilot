"""
Campaign entity (domain model).

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
