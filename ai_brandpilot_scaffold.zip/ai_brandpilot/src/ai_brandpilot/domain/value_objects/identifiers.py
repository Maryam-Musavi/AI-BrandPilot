"""
Strongly typed identifier value objects.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
