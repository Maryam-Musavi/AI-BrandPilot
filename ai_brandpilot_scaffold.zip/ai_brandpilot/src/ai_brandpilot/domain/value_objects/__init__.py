"""Immutable domain value objects."""
