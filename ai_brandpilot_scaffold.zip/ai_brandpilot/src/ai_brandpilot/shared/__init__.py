"""Cross-layer shared utilities and types with no business meaning."""
