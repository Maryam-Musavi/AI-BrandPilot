"""
Shared common type aliases.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
