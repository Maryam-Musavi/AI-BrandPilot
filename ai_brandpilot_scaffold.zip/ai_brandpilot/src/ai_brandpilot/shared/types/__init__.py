"""Shared type aliases and protocol definitions."""
