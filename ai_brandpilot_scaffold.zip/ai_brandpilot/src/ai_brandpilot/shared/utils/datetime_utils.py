"""
Shared datetime utility helpers (signatures only).

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
