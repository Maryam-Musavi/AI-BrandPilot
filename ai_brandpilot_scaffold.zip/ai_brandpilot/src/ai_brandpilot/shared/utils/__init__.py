"""Generic, stateless helper utilities."""
