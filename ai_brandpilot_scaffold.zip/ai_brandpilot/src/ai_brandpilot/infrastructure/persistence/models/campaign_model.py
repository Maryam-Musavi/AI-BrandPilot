"""
ORM model for Campaign persistence.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
