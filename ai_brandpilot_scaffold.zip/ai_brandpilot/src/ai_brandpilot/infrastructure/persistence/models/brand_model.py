"""
ORM model for Brand persistence.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
