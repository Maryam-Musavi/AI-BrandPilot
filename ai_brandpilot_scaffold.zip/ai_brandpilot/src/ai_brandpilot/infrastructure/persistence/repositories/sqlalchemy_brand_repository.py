"""
Concrete BrandRepository implementation (adapter).

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
