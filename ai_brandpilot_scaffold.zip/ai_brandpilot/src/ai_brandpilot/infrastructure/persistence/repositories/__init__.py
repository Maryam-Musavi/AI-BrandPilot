"""Concrete repository implementations (adapters for domain repository ports)."""
