"""Tool registry/adapters exposed to LangGraph (no tool logic)."""
