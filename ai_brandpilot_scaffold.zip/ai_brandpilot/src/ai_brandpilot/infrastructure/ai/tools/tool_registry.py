"""
Registry surface for LangGraph-compatible tools (no tool logic).

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
