"""LangGraph conditional routing/edge adapters."""
