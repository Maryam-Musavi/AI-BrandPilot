"""
LangGraph node adapter: brand analysis step.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
