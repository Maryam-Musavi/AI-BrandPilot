"""
LangGraph node adapter: content generation step.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
