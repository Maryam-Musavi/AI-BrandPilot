"""LangGraph node adapters."""
