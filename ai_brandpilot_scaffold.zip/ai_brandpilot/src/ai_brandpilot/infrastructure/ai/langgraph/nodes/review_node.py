"""
LangGraph node adapter: content review step.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
