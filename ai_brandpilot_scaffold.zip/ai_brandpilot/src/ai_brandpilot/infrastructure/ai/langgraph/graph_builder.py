"""
LangGraph graph construction/compilation entry point.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
