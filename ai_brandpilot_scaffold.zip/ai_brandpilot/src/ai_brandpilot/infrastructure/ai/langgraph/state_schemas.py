"""
Pydantic state schemas for LangGraph workflows.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
