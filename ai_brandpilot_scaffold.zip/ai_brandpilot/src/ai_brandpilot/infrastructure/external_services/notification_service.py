"""
Concrete notification interface implementation.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
