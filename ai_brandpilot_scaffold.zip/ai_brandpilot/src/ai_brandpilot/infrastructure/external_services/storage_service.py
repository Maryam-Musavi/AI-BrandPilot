"""
Concrete file/object storage service implementation.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
