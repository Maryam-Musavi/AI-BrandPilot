"""Adapters for third-party/external services."""
