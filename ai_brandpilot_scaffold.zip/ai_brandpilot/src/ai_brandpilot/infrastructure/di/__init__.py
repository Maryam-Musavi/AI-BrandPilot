"""Dependency injection container and provider wiring."""
