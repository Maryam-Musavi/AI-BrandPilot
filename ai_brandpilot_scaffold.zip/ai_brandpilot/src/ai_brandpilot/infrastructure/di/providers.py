"""
Dependency injection providers/factories.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
