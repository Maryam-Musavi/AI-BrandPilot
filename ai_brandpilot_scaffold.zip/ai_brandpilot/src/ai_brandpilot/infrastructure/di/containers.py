"""
Dependency injection container definitions.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
