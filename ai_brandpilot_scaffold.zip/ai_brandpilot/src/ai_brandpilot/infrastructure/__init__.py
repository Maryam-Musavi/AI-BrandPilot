"""Frameworks & drivers: persistence, AI orchestration, external services, dependency injection wiring."""
