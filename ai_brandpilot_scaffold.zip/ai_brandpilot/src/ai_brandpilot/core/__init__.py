"""Cross-cutting concerns: configuration, logging, exceptions, DI bootstrap."""
