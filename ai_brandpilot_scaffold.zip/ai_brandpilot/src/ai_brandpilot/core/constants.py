"""
Global constants shared across layers.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
