"""
Application configuration/settings management (env-driven).

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
