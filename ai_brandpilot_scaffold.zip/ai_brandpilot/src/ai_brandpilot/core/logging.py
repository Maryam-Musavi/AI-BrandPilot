"""
Centralized logging configuration.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
