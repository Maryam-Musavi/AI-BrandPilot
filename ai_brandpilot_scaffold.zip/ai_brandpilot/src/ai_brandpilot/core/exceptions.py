"""
Application-wide base exception classes.

This module intentionally contains no implementation.
Structure only, per Clean Architecture layering.
"""
