# Clean Architecture Rules

## The Dependency Rule

Source code dependencies point **inward only**:

```
presentation ──▶ application ──▶ domain
infrastructure ──▶ application ──▶ domain
                 (via interfaces/ports defined in domain & application)
```

- `domain` never imports from `application`, `infrastructure`, or
  `presentation`.
- `application` never imports from `infrastructure` or `presentation`.
- `infrastructure` and `presentation` may depend on `application` and
  `domain`, but only through their abstract interfaces (ports), never on
  each other's concrete classes.

## Ports & Adapters Mapping

| Port (interface)                                   | Location                                   | Adapter (implementation)                          | Location                                            |
|------------------------------------------------------|-----------------------------------------------|------------------------------------------------------|--------------------------------------------------------|
| `BrandRepository`                                     | `domain/repositories/brand_repository.py`     | `SqlAlchemyBrandRepository`                          | `infrastructure/persistence/repositories/`             |
| `CampaignRepository`                                   | `domain/repositories/campaign_repository.py`  | `SqlAlchemyCampaignRepository`                       | `infrastructure/persistence/repositories/`             |
| `ContentRepository`                                    | `domain/repositories/content_repository.py`   | `SqlAlchemyContentRepository`                        | `infrastructure/persistence/repositories/`             |
| `AgentOrchestratorInterface`                           | `application/interfaces/`                     | LangGraph graph builder                              | `infrastructure/ai/langgraph/graph_builder.py`         |
| `ToolProviderInterface`                                | `application/interfaces/`                     | Tool registry                                         | `infrastructure/ai/tools/tool_registry.py`             |
| `NotificationInterface`                                | `application/interfaces/`                     | `NotificationService`                                 | `infrastructure/external_services/notification_service.py` |

## Why LangGraph Sits in Infrastructure

LangGraph is a **framework/driver detail**, exactly like a database or an
HTTP client. The application layer depends only on
`AgentOrchestratorInterface`; it has no knowledge that LangGraph is the
underlying orchestration engine. This allows the orchestration engine to be
swapped without touching use cases.

## Use Case Flow (structural, no logic)

```
presentation/api/v1/endpoints/*  (FastAPI route)
        │  calls
        ▼
application/services/*           (Service Layer)
        │  delegates to
        ▼
application/use_cases/*          (single-purpose interactor)
        │  depends on ports
        ▼
domain/repositories/*  &  application/interfaces/*
        ▲
        │  implemented by
infrastructure/persistence/*  &  infrastructure/ai/*
```

## Enforcement

- Import direction should be checked in CI (e.g., via `import-linter` or
  equivalent) once implementation begins.
- Each module is expected to stay under ~300 lines; if a module grows
  beyond that, split by responsibility (SRP) rather than truncating.
