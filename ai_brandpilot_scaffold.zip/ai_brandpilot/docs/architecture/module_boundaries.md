# Module Boundaries

## Allowed Import Matrix

| From \ To          | domain | application | infrastructure | presentation | core | shared |
|---------------------|:------:|:-----------:|:----------------:|:--------------:|:----:|:------:|
| **domain**          |   ✅   |     ❌      |        ❌        |      ❌        |  ❌  |   ✅   |
| **application**     |   ✅   |     ✅      |        ❌        |      ❌        |  ✅  |   ✅   |
| **infrastructure**  |   ✅   |     ✅ (ports) |     ✅         |      ❌        |  ✅  |   ✅   |
| **presentation**    |   ❌   |     ✅ (ports) |     ❌ (direct) |      ✅        |  ✅  |   ✅   |
| **core**            |   ❌   |     ❌      |        ❌        |      ❌        |  ✅  |   ✅   |
| **shared**          |   ❌   |     ❌      |        ❌        |      ❌        |  ❌  |   ✅   |

- ✅ (ports) — allowed only through an abstract interface, never a concrete
  class from that layer.
- `presentation` never imports `infrastructure` directly; it resolves
  concrete instances only via `core/di_container.py`.

## Per-Feature Vertical Slice

Each business capability (Brand, Campaign, Content) is represented
consistently across layers:

```
domain/entities/brand.py
domain/repositories/brand_repository.py
application/dto/brand_dto.py
application/use_cases/brand/*
application/services/brand_service.py
infrastructure/persistence/models/brand_model.py
infrastructure/persistence/repositories/sqlalchemy_brand_repository.py
presentation/api/v1/endpoints/brand_endpoints.py
presentation/api/v1/schemas/brand_schema.py
```

This keeps each module small and single-purpose (SRP), and makes locating
all code related to one capability straightforward.

## Naming Conventions

| Artifact type        | Suffix                  | Example                          |
|------------------------|--------------------------|-------------------------------------|
| Domain entity          | *(none)*                | `Brand`                             |
| Value object           | *(none)*                | `ToneOfVoice`                       |
| Repository port        | `Repository`             | `BrandRepository`                   |
| Repository adapter     | `SqlAlchemy*Repository`  | `SqlAlchemyBrandRepository`         |
| Use case               | `UseCase`                | `CreateBrandUseCase`                |
| Application service    | `Service`                | `BrandService`                      |
| API schema             | `Schema`                 | `BrandCreateSchema`                 |
| DTO                    | `DTO`                    | `BrandDTO`                          |
