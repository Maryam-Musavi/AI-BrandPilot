# Architecture Diagram (Textual)

```
                        ┌───────────────────────────────────────┐
                        │              PRESENTATION               │
                        │  FastAPI routers · Pydantic schemas    │
                        │  middleware · HTTP-level DI            │
                        └───────────────────┬─────────────────────┘
                                            │ depends on (ports)
                                            ▼
                        ┌───────────────────────────────────────┐
                        │               APPLICATION                │
                        │  Use cases · Service layer · DTOs      │
                        │  AgentOrchestratorInterface            │
                        │  ToolProviderInterface                  │
                        │  NotificationInterface                  │
                        └───────────────────┬─────────────────────┘
                                            │ depends on
                                            ▼
                        ┌───────────────────────────────────────┐
                        │                 DOMAIN                    │
                        │  Entities · Value Objects               │
                        │  Repository interfaces (ports)          │
                        │  Domain services · Domain exceptions    │
                        └───────────────────▲─────────────────────┘
                                            │ implements ports
                        ┌───────────────────┴─────────────────────┐
                        │               INFRASTRUCTURE              │
                        │  SQLAlchemy repositories                │
                        │  LangGraph graph/nodes/edges            │
                        │  Tool registry · External services      │
                        │  DI container/providers                 │
                        └───────────────────────────────────────┘

                     ┌──────────────┐            ┌──────────────┐
                     │     CORE       │            │    SHARED      │
                     │ config/logging │            │ utils/types    │
                     │ exceptions     │            │ (no business   │
                     │ composition    │            │  meaning)      │
                     │ root           │            └──────────────┘
                     └──────────────┘
                (used by every layer)
```

## Request Lifecycle (structural, no logic)

```
Client
  │
  ▼
FastAPI Router (presentation/api/v1)
  │
  ▼
Pydantic Schema validation (presentation/api/v1/schemas)
  │
  ▼
FastAPI Dependency resolves Service (presentation/api/dependencies)
  │
  ▼
Application Service (application/services)
  │
  ▼
Use Case (application/use_cases)
  │
  ├──▶ Domain Repository Port ──▶ Infrastructure Repository Adapter ──▶ DB
  │
  └──▶ AgentOrchestratorInterface ──▶ LangGraph graph_builder ──▶ Nodes/Edges
  │
  ▼
DTO returned up the call stack
  │
  ▼
Pydantic Response Schema
  │
  ▼
Client
```
