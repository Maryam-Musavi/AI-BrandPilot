# Dependency Injection Strategy

## Composition Root

`core/di_container.py` is the single composition root of the application.
It is the only place where concrete infrastructure classes are wired to
the abstract ports they implement.

## Wiring Layers

```
infrastructure/di/providers.py    -> builds individual providers/factories
                                      (repositories, orchestrators, services)
infrastructure/di/containers.py   -> composes providers into a container
core/di_container.py              -> exposes the wired container to the app
presentation/api/dependencies/    -> FastAPI `Depends(...)` bridges that pull
service_dependencies.py              resolved services from the container
                                      into route handlers
```

## Resolution Flow (structural)

```
FastAPI route handler
   │  Depends(get_brand_service)
   ▼
presentation/api/dependencies/service_dependencies.py
   │  resolves from
   ▼
core/di_container.py
   │  composed via
   ▼
infrastructure/di/containers.py + providers.py
   │  injects concrete adapters into
   ▼
application/services/*  (Service Layer)
   │  constructed with
   ▼
domain/repositories/* (ports) + application/interfaces/* (ports)
```

## Principles

- Constructors receive interfaces/abstract types, never concrete
  infrastructure classes directly (Dependency Inversion).
- Object graph construction is centralized; no module reaches into the
  container to self-resolve dependencies ("service locator" antipattern is
  avoided).
- Test suites substitute fake/mock adapters at the same seams used by the
  DI container, enabling isolated unit testing of `domain` and
  `application` layers.
