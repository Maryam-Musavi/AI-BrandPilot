# Architecture Overview

## Purpose

This document describes the full directory structure of AI BrandPilot and
the responsibility of each layer. It is a reference for where new code
should be added — it does not contain implementation detail.

## Full Directory Tree

```
ai_brandpilot/
├── README.md
├── requirements.txt
├── docs/
│   ├── architecture/
│   │   ├── overview.md
│   │   ├── clean_architecture.md
│   │   ├── dependency_injection.md
│   │   ├── module_boundaries.md
│   │   └── diagrams/
│   │       └── architecture_diagram.md
│   ├── api/
│   │   └── endpoints.md
│   ├── adr/
│   │   └── 0001-initial-architecture.md
│   └── setup/
│       ├── installation.md
│       └── configuration.md
├── src/
│   └── ai_brandpilot/
│       ├── __init__.py
│       ├── main.py
│       ├── core/
│       │   ├── __init__.py
│       │   ├── config.py
│       │   ├── logging.py
│       │   ├── exceptions.py
│       │   ├── constants.py
│       │   └── di_container.py
│       ├── domain/
│       │   ├── __init__.py
│       │   ├── entities/
│       │   │   ├── __init__.py
│       │   │   ├── brand.py
│       │   │   ├── campaign.py
│       │   │   ├── content.py
│       │   │   └── user.py
│       │   ├── value_objects/
│       │   │   ├── __init__.py
│       │   │   ├── brand_identity.py
│       │   │   ├── tone_of_voice.py
│       │   │   └── identifiers.py
│       │   ├── repositories/
│       │   │   ├── __init__.py
│       │   │   ├── brand_repository.py
│       │   │   ├── campaign_repository.py
│       │   │   ├── content_repository.py
│       │   │   └── user_repository.py
│       │   ├── services/
│       │   │   ├── __init__.py
│       │   │   ├── brand_domain_service.py
│       │   │   └── content_domain_service.py
│       │   └── exceptions/
│       │       ├── __init__.py
│       │       └── domain_exceptions.py
│       ├── application/
│       │   ├── __init__.py
│       │   ├── dto/
│       │   │   ├── __init__.py
│       │   │   ├── brand_dto.py
│       │   │   ├── campaign_dto.py
│       │   │   └── content_dto.py
│       │   ├── interfaces/
│       │   │   ├── __init__.py
│       │   │   ├── agent_orchestrator_interface.py
│       │   │   ├── tool_provider_interface.py
│       │   │   └── notification_interface.py
│       │   ├── use_cases/
│       │   │   ├── __init__.py
│       │   │   ├── brand/
│       │   │   │   ├── __init__.py
│       │   │   │   ├── create_brand_use_case.py
│       │   │   │   ├── update_brand_use_case.py
│       │   │   │   └── get_brand_use_case.py
│       │   │   ├── campaign/
│       │   │   │   ├── __init__.py
│       │   │   │   ├── create_campaign_use_case.py
│       │   │   │   └── generate_campaign_content_use_case.py
│       │   │   └── content/
│       │   │       ├── __init__.py
│       │   │       ├── generate_content_use_case.py
│       │   │       └── review_content_use_case.py
│       │   └── services/
│       │       ├── __init__.py
│       │       ├── brand_service.py
│       │       ├── campaign_service.py
│       │       └── content_service.py
│       ├── infrastructure/
│       │   ├── __init__.py
│       │   ├── persistence/
│       │   │   ├── __init__.py
│       │   │   ├── database.py
│       │   │   ├── models/
│       │   │   │   ├── __init__.py
│       │   │   │   ├── brand_model.py
│       │   │   │   ├── campaign_model.py
│       │   │   │   └── content_model.py
│       │   │   └── repositories/
│       │   │       ├── __init__.py
│       │   │       ├── sqlalchemy_brand_repository.py
│       │   │       ├── sqlalchemy_campaign_repository.py
│       │   │       └── sqlalchemy_content_repository.py
│       │   ├── ai/
│       │   │   ├── __init__.py
│       │   │   ├── langgraph/
│       │   │   │   ├── __init__.py
│       │   │   │   ├── graph_builder.py
│       │   │   │   ├── state_schemas.py
│       │   │   │   ├── nodes/
│       │   │   │   │   ├── __init__.py
│       │   │   │   │   ├── brand_analysis_node.py
│       │   │   │   │   ├── content_generation_node.py
│       │   │   │   │   └── review_node.py
│       │   │   │   └── edges/
│       │   │   │       ├── __init__.py
│       │   │   │       └── routing.py
│       │   │   └── tools/
│       │   │       ├── __init__.py
│       │   │       └── tool_registry.py
│       │   ├── external_services/
│       │   │   ├── __init__.py
│       │   │   ├── notification_service.py
│       │   │   └── storage_service.py
│       │   └── di/
│       │       ├── __init__.py
│       │       ├── containers.py
│       │       └── providers.py
│       ├── presentation/
│       │   ├── __init__.py
│       │   ├── api/
│       │   │   ├── __init__.py
│       │   │   ├── v1/
│       │   │   │   ├── __init__.py
│       │   │   │   ├── router.py
│       │   │   │   ├── endpoints/
│       │   │   │   │   ├── __init__.py
│       │   │   │   │   ├── brand_endpoints.py
│       │   │   │   │   ├── campaign_endpoints.py
│       │   │   │   │   ├── content_endpoints.py
│       │   │   │   │   └── health_endpoints.py
│       │   │   │   └── schemas/
│       │   │   │       ├── __init__.py
│       │   │   │       ├── brand_schema.py
│       │   │   │       ├── campaign_schema.py
│       │   │   │       └── content_schema.py
│       │   │   └── dependencies/
│       │   │       ├── __init__.py
│       │   │       ├── service_dependencies.py
│       │   │       └── auth_dependencies.py
│       │   └── middleware/
│       │       ├── __init__.py
│       │       ├── error_handler.py
│       │       ├── logging_middleware.py
│       │       └── cors_middleware.py
│       └── shared/
│           ├── __init__.py
│           ├── utils/
│           │   ├── __init__.py
│           │   └── datetime_utils.py
│           └── types/
│               ├── __init__.py
│               └── common_types.py
└── tests/
    ├── __init__.py
    ├── unit/
    │   ├── __init__.py
    │   ├── domain/
    │   │   └── __init__.py
    │   ├── application/
    │   │   └── __init__.py
    │   └── infrastructure/
    │       └── __init__.py
    ├── integration/
    │   ├── __init__.py
    │   └── api/
    │       └── __init__.py
    └── conftest.py
```

## Layer Responsibilities

| Layer            | Responsibility                                                        | Depends on              |
|-------------------|------------------------------------------------------------------------|---------------------------|
| `domain`          | Entities, value objects, repository/service ports, domain exceptions   | Nothing (pure Python)     |
| `application`     | Use cases, DTOs, application services, orchestration/tool ports        | `domain`                  |
| `infrastructure`  | Repository implementations, LangGraph adapters, external service adapters, DI wiring | `domain`, `application` (via ports) |
| `presentation`    | FastAPI routers, request/response schemas, middleware, HTTP-level DI   | `application` (via ports) |
| `core`            | Configuration, logging, exceptions, composition root                   | Used by all layers        |
| `shared`          | Framework-agnostic utilities/types with no business meaning            | Used by all layers        |
