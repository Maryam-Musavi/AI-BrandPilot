# API Reference — v1 (Structure Only)

Base path: `/api/v1`

Endpoint bodies are intentionally unimplemented. This document records the
planned resource surface so route files, schemas, and services stay aligned.

## Health

| Method | Path            | Module                                                   |
|--------|-----------------|-----------------------------------------------------------|
| GET    | `/health`       | `presentation/api/v1/endpoints/health_endpoints.py`        |

## Brand

| Method | Path                | Module                                                       | Schema module                                          |
|--------|---------------------|------------------------------------------------------------------|-----------------------------------------------------------|
| POST   | `/brands`           | `presentation/api/v1/endpoints/brand_endpoints.py`                | `presentation/api/v1/schemas/brand_schema.py`              |
| GET    | `/brands/{id}`      | `presentation/api/v1/endpoints/brand_endpoints.py`                | `presentation/api/v1/schemas/brand_schema.py`              |
| PATCH  | `/brands/{id}`      | `presentation/api/v1/endpoints/brand_endpoints.py`                | `presentation/api/v1/schemas/brand_schema.py`              |

## Campaign

| Method | Path                                | Module                                                            |
|--------|--------------------------------------|------------------------------------------------------------------------|
| POST   | `/campaigns`                        | `presentation/api/v1/endpoints/campaign_endpoints.py`                    |
| POST   | `/campaigns/{id}/generate-content`  | `presentation/api/v1/endpoints/campaign_endpoints.py`                    |

## Content

| Method | Path                     | Module                                                     |
|--------|---------------------------|-----------------------------------------------------------------|
| POST   | `/content/generate`      | `presentation/api/v1/endpoints/content_endpoints.py`              |
| POST   | `/content/{id}/review`   | `presentation/api/v1/endpoints/content_endpoints.py`              |

## Router Aggregation

All resource routers are mounted through
`presentation/api/v1/router.py`, which is included once into the FastAPI
`app` instance created in `main.py`.
