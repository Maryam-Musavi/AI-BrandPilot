# Configuration Reference

Configuration is expected to be sourced from environment variables and
loaded through `core/config.py` (a Pydantic `Settings` model, once
implemented).

## Planned Configuration Categories

| Category            | Example variables (names only)         | Consumed by                    |
|-----------------------|------------------------------------------|-----------------------------------|
| Application           | `APP_ENV`, `APP_DEBUG`, `APP_PORT`       | `core/config.py`                   |
| Database              | `DATABASE_URL`                           | `infrastructure/persistence/database.py` |
| LangGraph / LLM       | `LLM_PROVIDER`, `LLM_MODEL`              | `infrastructure/ai/langgraph/*`    |
| Logging               | `LOG_LEVEL`, `LOG_FORMAT`                | `core/logging.py`                  |
| External services     | `NOTIFICATION_PROVIDER_URL`              | `infrastructure/external_services/*` |

No default values, secrets, or actual configuration logic are defined at
this stage — this document exists to reserve the shape of configuration so
`core/config.py` can be implemented consistently later.
