# Installation

## Prerequisites

- Python 3.13
- pip (or uv/poetry, if adopted later)

## Steps

```bash
# 1. Create and activate a virtual environment
python3.13 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. (Once implemented) run the application
uvicorn src.ai_brandpilot.main:app --reload
```

## Directory You'll Work In

```
src/ai_brandpilot/   # application source code
tests/               # unit and integration tests
docs/                # architecture & API documentation
```

Configuration details are documented separately in
[`configuration.md`](configuration.md).
