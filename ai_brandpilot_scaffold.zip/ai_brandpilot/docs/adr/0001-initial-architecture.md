# ADR 0001: Adopt Clean Architecture with FastAPI + LangGraph

## Status
Accepted

## Context
AI BrandPilot must support long-lived, evolving AI agent workflows
(via LangGraph) alongside conventional CRUD and HTTP concerns (via
FastAPI), while remaining testable, maintainable, and framework-agnostic
at its core.

## Decision
- Adopt **Clean Architecture** with four layers: `domain`, `application`,
  `infrastructure`, `presentation`, plus cross-cutting `core` and `shared`.
- Treat **LangGraph as an infrastructure adapter**, accessed exclusively
  through an `AgentOrchestratorInterface` port defined in `application`.
- Treat **FastAPI as a presentation-layer detail**; route handlers contain
  no business logic and delegate to the application service layer.
- Use **Pydantic** for both API schemas (`presentation`) and LangGraph
  state schemas (`infrastructure/ai/langgraph`), keeping the two
  independent so a change in one does not force a change in the other.
- Apply the **Repository Pattern** for all persistence access, with
  interfaces in `domain/repositories` and implementations in
  `infrastructure/persistence/repositories`.
- Apply a **Service Layer** in `application/services` to coordinate use
  cases, keeping route handlers thin.
- Wire all dependencies through a single **composition root**
  (`core/di_container.py`), backed by `infrastructure/di`.

## Consequences
- Business rules in `domain`/`application` are testable without FastAPI,
  LangGraph, or a database.
- LangGraph, the database engine, or the web framework can each be
  replaced independently with minimal blast radius.
- Slightly more boilerplate (ports + adapters) in exchange for long-term
  maintainability and testability.

## Alternatives Considered
- **Layered "fat services" architecture** without explicit ports — rejected
  due to tighter coupling to LangGraph/FastAPI internals.
- **Framework-centric structure** (routes calling ORM models directly) —
  rejected; would hinder unit testing and future orchestration-engine
  changes.
