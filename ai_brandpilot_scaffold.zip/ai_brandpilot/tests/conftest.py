"""
Shared pytest fixtures for AI BrandPilot test suite.

No fixtures implemented — structure placeholder only.
"""
