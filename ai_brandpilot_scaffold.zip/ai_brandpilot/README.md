# AI BrandPilot

Production-grade AI system for automated brand strategy, campaign
management, and AI-generated content — built on Clean Architecture
principles with FastAPI and LangGraph.

> This repository currently contains **architecture scaffolding only**.
> No business logic, AI logic, or tool implementations are included.

---

## 1. Tech Stack

| Concern                | Technology            |
|-------------------------|------------------------|
| Language                | Python 3.13            |
| Web Framework           | FastAPI                |
| Agent Orchestration     | LangGraph              |
| Data Validation         | Pydantic v2            |
| Architecture Style      | Clean Architecture     |
| Design Principles       | SOLID                  |
| Dependency Management   | Dependency Injection   |
| Data Access Pattern     | Repository Pattern     |
| Business Logic Pattern  | Service Layer          |

---

## 2. Architectural Layers

```
presentation   -> FastAPI routers, schemas, middleware, DI wiring for HTTP
application    -> Use cases, DTOs, service layer, orchestration interfaces
domain         -> Entities, value objects, repository interfaces (ports)
infrastructure -> Persistence, LangGraph adapters, external services, DI container
shared         -> Cross-cutting, framework-agnostic utilities and types
core           -> Configuration, logging, exceptions, composition root
```

Dependency rule: **outer layers depend on inner layers, never the reverse.**
`domain` has zero framework dependencies. `application` depends only on
`domain`. `infrastructure` and `presentation` depend on `application` and
`domain` through interfaces (ports), never directly on concrete details of
one another.

---

## 3. Project Structure

See [`docs/architecture/overview.md`](docs/architecture/overview.md) for the
full annotated directory tree.

```
ai_brandpilot/
├── README.md
├── requirements.txt
├── docs/
├── src/ai_brandpilot/
│   ├── main.py
│   ├── core/
│   ├── domain/
│   ├── application/
│   ├── infrastructure/
│   ├── presentation/
│   └── shared/
└── tests/
    ├── unit/
    └── integration/
```

---

## 4. Design Principles Applied

- **S**ingle Responsibility — one module/class per concern; modules capped
  at ~300 lines.
- **O**pen/Closed — new use cases and LangGraph nodes extend the system
  without modifying existing ports.
- **L**iskov Substitution — repository/service interfaces are fully
  substitutable by any concrete adapter.
- **I**nterface Segregation — narrow, purpose-specific interfaces under
  `domain/repositories` and `application/interfaces`.
- **D**ependency Inversion — high-level modules (`application`, `domain`)
  depend on abstractions; `infrastructure` provides implementations, wired
  via `infrastructure/di`.

---

## 5. Getting Started

Setup and run instructions will live in
[`docs/setup/installation.md`](docs/setup/installation.md) once
implementation begins.

```bash
python3.13 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## 6. Documentation Index

| Doc                                             | Purpose                                   |
|--------------------------------------------------|--------------------------------------------|
| `docs/architecture/overview.md`                  | Full directory tree & layer responsibilities |
| `docs/architecture/clean_architecture.md`        | Layering rules & dependency direction      |
| `docs/architecture/dependency_injection.md`      | DI container/provider wiring strategy      |
| `docs/architecture/module_boundaries.md`         | Allowed imports between layers             |
| `docs/architecture/diagrams/architecture_diagram.md` | Textual architecture diagram            |
| `docs/api/endpoints.md`                          | API surface (v1) reference                 |
| `docs/adr/0001-initial-architecture.md`          | Architecture Decision Record                |
| `docs/setup/installation.md`                     | Local environment setup                    |
| `docs/setup/configuration.md`                    | Environment/config reference                |

---

## 7. Testing Strategy

```
tests/
├── unit/            # domain, application, infrastructure — isolated, mocked ports
├── integration/api  # FastAPI endpoint-level tests
└── conftest.py      # shared fixtures
```

---

## 8. Status

🚧 Architecture scaffold only. Business logic, LangGraph graphs/nodes,
tool implementations, and persistence logic are intentionally unimplemented.
